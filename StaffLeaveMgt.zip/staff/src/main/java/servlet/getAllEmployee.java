package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.employee;
import services.employeeservice;

@WebServlet("/getAllEmployee")
public class getAllEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public getAllEmployee() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		employeeservice service = new employeeservice();  		// Creating an instance of the EmployeeService class

		employee emp = new employee();        // Creating an instance of the Employee class

		// Setting employee data from request parameters
		emp.setEmployee_id(request.getParameter("employee_id"));
		emp.setName(request.getParameter("Name"));
		emp.setEmail(request.getParameter("Email"));
		emp.setStart_date(request.getParameter("Start_date"));
		emp.setEnd_date(request.getParameter("End_date"));
		emp.setReason(request.getParameter("Reason"));
		
		service.updateEmp(emp); // Calling the updateEmp method from the EmployeeService class

		
		ArrayList<employee> employee = service.getAllEmployee();   // Getting all employees from the service
		
		request.setAttribute("employee", employee);  		// Setting employees as an attribute in the request

		// Forwarding the request to the "getAllTable.jsp"
		RequestDispatcher dispatcher = request.getRequestDispatcher("getAllTable.jsp");
		
		dispatcher.forward(request, response);
	}

}

package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.employee;
import services.employeeservice;


@WebServlet("/delete")
public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public delete() {  // Constructor for the servlet
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Sending a response indicating the server is serving at a specific context path
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		employee emp = new employee();  // Creating an instance of the Employee model class
		emp.setEmployee_id(request.getParameter("employee_id"));   // Setting the employee ID from the request parameters
		
		employeeservice service = new employeeservice();  // Creating an instance of the service class for employee operations
		service.deleteEmp(emp);  // Calling the deleteEmp method of the service to delete the employee
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("getAllEmployee");          // Getting a request dispatcher to forward the request to another servlet 

		
		dispatcher.forward(request, response);   // Forwarding the request and response objects to another JSP
	}

}

package services;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import model.employee;
import utils.DBConnect;

public class employeeservice {
	public void applytimeoff(employee emp) {
		try {
			
			
			String query="insert into employee values('"+emp.getEmployee_id()+"','"+emp.getName()+"','"+emp.getEmail()+"','"+emp.getStart_date()+"','"+emp.getEnd_date()+"','"+emp.getReason()+"')";
			
			Statement statement = DBConnect.getconnection().createStatement();
			statement.executeUpdate(query);
			
			
		}catch(Exception e) {
			e.printStackTrace();
			
		}
}
	
	public ArrayList<employee> getAllEmployee(){
		try {
			
			ArrayList<employee> listEmp = new ArrayList<employee>();
			
			String query = "select * from employee";
			
			Statement statement = DBConnect.getconnection().createStatement();
			
			ResultSet rs = statement.executeQuery(query);
			
			while(rs.next()) {
				
				employee emp = new employee();
				
				emp.setEmployee_id(rs.getString("employee_id"));
				emp.setName(rs.getString("Name"));
				emp.setEmail(rs.getString("Email"));
				emp.setStart_date(rs.getString("Start_date"));
				emp.setEnd_date(rs.getString("End_date"));
				emp.setReason(rs.getString("Reason"));
				
				listEmp.add(emp);
				
			}
			
			return listEmp;
			
		} catch (Exception e) {
			
			e.printStackTrace();
			return null;
			
		}
	}

	public void updateEmp(employee emp) {
		
		try {
			
			String query = "UPDATE employee SET Name = ?, Email = ?, Start_date = ?, End_date = ?, Reason = ? WHERE employee_id = ?";
			PreparedStatement statement = DBConnect.getconnection().prepareStatement(query);
			
			
			statement.setString(1, emp.getName());
			
			statement.setString(2, emp.getEmail());
			statement.setString(3, emp.getStart_date());
			statement.setString(4, emp.getEnd_date());
			statement.setString(5, emp.getReason());
			statement.setString(6, emp.getEmployee_id());
			
			System.out.println(statement);
			statement.executeUpdate();		
	
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void deleteEmp(employee emp) {
		try {
			
			String query = "delete from employee where employee_id = '"+emp.getEmployee_id()+"'";
			
			Statement statement = DBConnect.getconnection().createStatement();
			
			statement.executeUpdate(query);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
			
}
}
